
import React, { useState } from 'react';
import { ExamData, Question, QuestionType } from '../types';
import { Plus, Trash2, Wand2, Image as ImageIcon, ChevronDown, ChevronUp, ArrowUp, ArrowDown, XCircle, Settings, Type } from 'lucide-react';

interface EditorProps {
  data: ExamData;
  onChange: (newData: ExamData) => void;
  onGenerateAI: () => void;
  isGenerating: boolean;
}

const Editor: React.FC<EditorProps> = ({ data, onChange, onGenerateAI, isGenerating }) => {
  const [collapsed, setCollapsed] = useState({
    header: false,
    settings: false,
    mcqs: false,
    short: false,
    long: false
  });

  const toggleSection = (section: keyof typeof collapsed) => {
    setCollapsed(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const updateHeader = (field: string, value: any) => {
    onChange({
      ...data,
      header: { ...data.header, [field]: value }
    });
  };

  const updateSettings = (field: string, value: any) => {
    onChange({
      ...data,
      settings: { ...data.settings, [field]: value }
    });
  };

  const updateInstruction = (field: 'mcqInstruction' | 'shortInstruction' | 'longInstruction', value: string) => {
    onChange({
      ...data,
      [field]: value
    });
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>, side: 'left' | 'right') => {
    const file = e.target.files?.[0];
    if (file) {
      // Basic validation for image type
      if (!file.type.match(/image\/(jpeg|jpg|png)/)) {
          alert("Please upload a PNG or JPEG image only.");
          return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        updateHeader(side === 'left' ? 'logoUrl' : 'logoRightUrl', reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const addQuestion = (type: QuestionType) => {
    const newQ: Question = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      text: "",
      options: type === 'MCQ' ? ["", "", "", ""] : undefined,
      marks: type === 'MCQ' ? 1 : (type === 'SHORT' ? 5 : 10)
    };
    
    if (type === 'MCQ') onChange({ ...data, mcqs: [...data.mcqs, newQ] });
    if (type === 'SHORT') onChange({ ...data, shortQuestions: [...data.shortQuestions, newQ] });
    if (type === 'LONG') onChange({ ...data, longQuestions: [...data.longQuestions, newQ] });
  };

  const updateQuestion = (type: QuestionType, id: string, field: string, value: any, optionIndex?: number) => {
    const updateList = (list: Question[]) => list.map(q => {
      if (q.id !== id) return q;
      if (field === 'options' && typeof optionIndex === 'number' && q.options) {
        const newOpts = [...q.options];
        newOpts[optionIndex] = value;
        return { ...q, options: newOpts };
      }
      return { ...q, [field]: value };
    });

    if (type === 'MCQ') onChange({ ...data, mcqs: updateList(data.mcqs) });
    if (type === 'SHORT') onChange({ ...data, shortQuestions: updateList(data.shortQuestions) });
    if (type === 'LONG') onChange({ ...data, longQuestions: updateList(data.longQuestions) });
  };

  const deleteQuestion = (type: QuestionType, id: string) => {
    if (type === 'MCQ') onChange({ ...data, mcqs: data.mcqs.filter(q => q.id !== id) });
    if (type === 'SHORT') onChange({ ...data, shortQuestions: data.shortQuestions.filter(q => q.id !== id) });
    if (type === 'LONG') onChange({ ...data, longQuestions: data.longQuestions.filter(q => q.id !== id) });
  };

  const moveQuestion = (type: QuestionType, index: number, direction: 'up' | 'down') => {
    const listKey = type === 'MCQ' ? 'mcqs' : type === 'SHORT' ? 'shortQuestions' : 'longQuestions';
    const list = [...data[listKey]];
    
    if (direction === 'up' && index > 0) {
      [list[index], list[index - 1]] = [list[index - 1], list[index]];
    } else if (direction === 'down' && index < list.length - 1) {
      [list[index], list[index + 1]] = [list[index + 1], list[index]];
    } else {
      return;
    }

    onChange({ ...data, [listKey]: list });
  };

  const clearSection = (type: QuestionType) => {
      if(!window.confirm(`Are you sure you want to clear all ${type} questions?`)) return;
      if (type === 'MCQ') onChange({ ...data, mcqs: [] });
      if (type === 'SHORT') onChange({ ...data, shortQuestions: [] });
      if (type === 'LONG') onChange({ ...data, longQuestions: [] });
  }

  const renderSectionHeader = (title: string, type: keyof typeof collapsed, count: number, onClear?: () => void, onAdd?: () => void) => (
    <div className="flex justify-between items-center bg-gray-100 p-2 rounded cursor-pointer select-none mb-2" onClick={() => toggleSection(type)}>
        <div className="flex items-center gap-2">
            {collapsed[type] ? <ChevronDown size={16} /> : <ChevronUp size={16} />}
            <h3 className="text-sm font-bold text-gray-700 uppercase tracking-wider">{title} {count > 0 && `(${count})`}</h3>
        </div>
        <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
           {onClear && (
               <button onClick={onClear} className="text-gray-400 hover:text-red-500 p-1" title="Clear Section">
                   <XCircle size={14} />
               </button>
           )}
           {onAdd && (
               <button onClick={onAdd} className="bg-blue-600 text-white p-1 rounded hover:bg-blue-700 shadow-sm">
                   <Plus size={14} />
               </button>
           )}
        </div>
    </div>
  );

  return (
    <div className="h-full overflow-y-auto bg-white border-r border-gray-200 p-4 w-full md:w-[450px] shadow-lg flex-shrink-0 flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold text-gray-800">Exam Editor</h2>
      </div>

      {/* Header Fields */}
      <div className="mb-6">
        {renderSectionHeader("Header Details", 'header', 0)}
        {!collapsed.header && (
            <div className="space-y-4 px-1">
                <div className="grid gap-3">
                <input 
                    className="border p-2 rounded text-sm w-full" 
                    placeholder="School Name"
                    value={data.header.schoolName}
                    onChange={(e) => updateHeader('schoolName', e.target.value)}
                />
                <input 
                    className="border p-2 rounded text-sm w-full" 
                    placeholder="Campus Name (Optional)"
                    value={data.header.campus || ''}
                    onChange={(e) => updateHeader('campus', e.target.value)}
                />
                <input 
                    className="border p-2 rounded text-sm w-full" 
                    placeholder="Exam Title (e.g. Final Term)"
                    value={data.header.examTitle}
                    onChange={(e) => updateHeader('examTitle', e.target.value)}
                />
                <div className="grid grid-cols-2 gap-2">
                    <input 
                    className="border p-2 rounded text-sm" 
                    placeholder="Subject"
                    value={data.header.subject}
                    onChange={(e) => updateHeader('subject', e.target.value)}
                    />
                    <input 
                    className="border p-2 rounded text-sm" 
                    placeholder="Class (e.g. 9th)"
                    value={data.header.classGrade}
                    onChange={(e) => updateHeader('classGrade', e.target.value)}
                    />
                </div>

                <div className="grid grid-cols-2 gap-2">
                    <input 
                    className="border p-2 rounded text-sm" 
                    placeholder="Date"
                    value={data.header.date}
                    onChange={(e) => updateHeader('date', e.target.value)}
                    />
                    <input 
                    className="border p-2 rounded text-sm" 
                    placeholder="Time"
                    value={data.header.time}
                    onChange={(e) => updateHeader('time', e.target.value)}
                    />
                </div>

                <div>
                    <input 
                    type="number"
                    className="border p-2 rounded text-sm w-full" 
                    placeholder="Total Marks"
                    value={data.header.totalMarks}
                    onChange={(e) => updateHeader('totalMarks', Number(e.target.value))}
                    />
                </div>
                
                {/* Logo Uploads */}
                <div className="mt-2 grid grid-cols-2 gap-2">
                    <div>
                        <label className="block text-xs font-semibold text-gray-500 mb-1 flex items-center gap-1">
                        <ImageIcon size={12} />
                        Left Logo (Govt)
                        </label>
                        <div className="flex items-center gap-2 bg-gray-50 p-2 rounded border border-dashed border-gray-300">
                            {data.header.logoUrl ? (
                                <div className="relative group flex-1 flex justify-center">
                                <img src={data.header.logoUrl} className="w-10 h-10 object-contain border rounded bg-white" alt="preview" />
                                <button 
                                    onClick={() => updateHeader('logoUrl', '')}
                                    className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                                    title="Remove Logo"
                                >
                                    <Trash2 size={10} />
                                </button>
                                </div>
                            ) : (
                            <div className="w-10 h-10 bg-gray-200 rounded flex items-center justify-center text-gray-400 flex-1">
                                <ImageIcon size={16} />
                            </div>
                            )}
                            <input 
                                type="file" 
                                accept="image/png, image/jpeg, image/jpg" 
                                onChange={(e) => handleLogoUpload(e, 'left')}
                                className="hidden"
                                id="logo-left-upload"
                            />
                            <label htmlFor="logo-left-upload" className="cursor-pointer bg-blue-50 text-blue-700 text-xs px-2 py-1 rounded hover:bg-blue-100">
                                Upload
                            </label>
                        </div>
                    </div>

                    <div>
                        <label className="block text-xs font-semibold text-gray-500 mb-1 flex items-center gap-1">
                        <ImageIcon size={12} />
                        Right Logo (School)
                        </label>
                        <div className="flex items-center gap-2 bg-gray-50 p-2 rounded border border-dashed border-gray-300">
                            {data.header.logoRightUrl ? (
                                <div className="relative group flex-1 flex justify-center">
                                <img src={data.header.logoRightUrl} className="w-10 h-10 object-contain border rounded bg-white" alt="preview" />
                                <button 
                                    onClick={() => updateHeader('logoRightUrl', '')}
                                    className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                                    title="Remove Logo"
                                >
                                    <Trash2 size={10} />
                                </button>
                                </div>
                            ) : (
                            <div className="w-10 h-10 bg-gray-200 rounded flex items-center justify-center text-gray-400 flex-1">
                                <ImageIcon size={16} />
                            </div>
                            )}
                            <input 
                                type="file" 
                                accept="image/png, image/jpeg, image/jpg" 
                                onChange={(e) => handleLogoUpload(e, 'right')}
                                className="hidden"
                                id="logo-right-upload"
                            />
                            <label htmlFor="logo-right-upload" className="cursor-pointer bg-blue-50 text-blue-700 text-xs px-2 py-1 rounded hover:bg-blue-100">
                                Upload
                            </label>
                        </div>
                    </div>
                </div>

                </div>
            </div>
        )}
      </div>

       {/* Paper Settings */}
      <div className="mb-6">
        {renderSectionHeader("Paper Settings", 'settings', 0)}
        {!collapsed.settings && (
            <div className="space-y-4 px-1 bg-gray-50 p-3 rounded border border-gray-200">
                <div>
                     <label className="flex items-center gap-2 text-xs font-bold text-gray-700 mb-1">
                         <Type size={14}/> Font Size Scale ({data.settings.fontScale})
                     </label>
                     <input 
                        type="range"
                        min="0.8"
                        max="1.4"
                        step="0.05"
                        value={data.settings.fontScale}
                        onChange={(e) => updateSettings('fontScale', parseFloat(e.target.value))}
                        className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                     />
                     <div className="flex justify-between text-xs text-gray-400 mt-1">
                         <span>Small</span>
                         <span>Default</span>
                         <span>Large</span>
                     </div>
                </div>
                
                <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">Watermark Text</label>
                    <input 
                        className="border p-2 rounded text-sm w-full"
                        placeholder="e.g. CONFIDENTIAL"
                        value={data.settings.watermarkText || ''}
                        onChange={(e) => updateSettings('watermarkText', e.target.value)}
                    />
                </div>

                 <div className="flex items-center gap-2">
                    <input 
                        type="checkbox" 
                        id="border-toggle"
                        checked={data.settings.showBorder}
                        onChange={(e) => updateSettings('showBorder', e.target.checked)}
                        className="w-4 h-4 text-blue-600 rounded"
                    />
                    <label htmlFor="border-toggle" className="text-sm font-medium text-gray-700">Show Page Border</label>
                </div>
            </div>
        )}
      </div>

      {/* MCQs */}
      <div className="mb-6">
        {renderSectionHeader("MCQs", 'mcqs', data.mcqs.length, () => clearSection('MCQ'), () => addQuestion('MCQ'))}
        {!collapsed.mcqs && (
            <div className="space-y-4">
                <div className="bg-blue-50 p-2 rounded border border-blue-100">
                     <label className="block text-xs font-bold text-blue-700 mb-1">Instruction Text</label>
                     <input
                        className="w-full text-sm p-2 border rounded"
                        value={data.mcqInstruction}
                        onChange={(e) => updateInstruction('mcqInstruction', e.target.value)}
                     />
                </div>
                {data.mcqs.map((q, i) => (
                    <div key={q.id} className="bg-gray-50 p-3 rounded border border-gray-200 shadow-sm relative group">
                         <div className="absolute right-2 top-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                             <button onClick={() => moveQuestion('MCQ', i, 'up')} disabled={i === 0} className="p-1 text-gray-400 hover:text-blue-500 disabled:opacity-30"><ArrowUp size={14}/></button>
                             <button onClick={() => moveQuestion('MCQ', i, 'down')} disabled={i === data.mcqs.length - 1} className="p-1 text-gray-400 hover:text-blue-500 disabled:opacity-30"><ArrowDown size={14}/></button>
                         </div>
                        <div className="flex gap-2 mb-2 pr-12">
                            <span className="text-xs font-bold text-gray-400 mt-2">{i+1}.</span>
                            <textarea 
                                className="w-full text-sm p-2 border rounded resize-y min-h-[60px]"
                                placeholder="Question text..."
                                value={q.text}
                                onChange={(e) => updateQuestion('MCQ', q.id, 'text', e.target.value)}
                            />
                            <button onClick={() => deleteQuestion('MCQ', q.id)} className="text-red-400 hover:text-red-600 self-start p-1"><Trash2 size={16} /></button>
                        </div>
                        <div className="grid grid-cols-2 gap-2 pl-6">
                            {q.options?.map((opt, idx) => (
                                <input 
                                    key={idx}
                                    className="border p-1 rounded text-xs w-full" 
                                    placeholder={`Option ${String.fromCharCode(65+idx)}`}
                                    value={opt}
                                    onChange={(e) => updateQuestion('MCQ', q.id, 'options', e.target.value, idx)}
                                />
                            ))}
                        </div>
                    </div>
                ))}
            </div>
        )}
      </div>

      {/* Short Questions */}
      <div className="mb-6">
        {renderSectionHeader("Short Questions", 'short', data.shortQuestions.length, () => clearSection('SHORT'), () => addQuestion('SHORT'))}
        {!collapsed.short && (
            <div className="space-y-2">
                 <div className="bg-blue-50 p-2 rounded border border-blue-100 mb-2">
                     <label className="block text-xs font-bold text-blue-700 mb-1">Instruction Text</label>
                     <input
                        className="w-full text-sm p-2 border rounded"
                        value={data.shortInstruction}
                        onChange={(e) => updateInstruction('shortInstruction', e.target.value)}
                     />
                </div>
                {data.shortQuestions.map((q, i) => (
                    <div key={q.id} className="flex gap-2 bg-gray-50 p-2 rounded border border-gray-200 items-start group relative">
                         <div className="flex flex-col pt-1 opacity-0 group-hover:opacity-100 transition-opacity absolute -left-6 top-0 h-full justify-center">
                             <button onClick={() => moveQuestion('SHORT', i, 'up')} disabled={i === 0} className="p-1 text-gray-400 hover:text-blue-500 disabled:opacity-30"><ArrowUp size={14}/></button>
                             <button onClick={() => moveQuestion('SHORT', i, 'down')} disabled={i === data.shortQuestions.length - 1} className="p-1 text-gray-400 hover:text-blue-500 disabled:opacity-30"><ArrowDown size={14}/></button>
                         </div>
                        <span className="text-xs font-bold text-gray-400 mt-2">{i+1}.</span>
                        <textarea 
                            className="w-full text-sm p-2 border rounded resize-y"
                            placeholder="Question text..."
                            value={q.text}
                            onChange={(e) => updateQuestion('SHORT', q.id, 'text', e.target.value)}
                        />
                        <button onClick={() => deleteQuestion('SHORT', q.id)} className="text-red-400 hover:text-red-600 mt-2"><Trash2 size={16} /></button>
                    </div>
                ))}
            </div>
        )}
      </div>

      {/* Long Questions */}
      <div className="mb-6">
        {renderSectionHeader("Long Questions", 'long', data.longQuestions.length, () => clearSection('LONG'), () => addQuestion('LONG'))}
        {!collapsed.long && (
            <div className="space-y-2">
                 <div className="bg-blue-50 p-2 rounded border border-blue-100 mb-2">
                     <label className="block text-xs font-bold text-blue-700 mb-1">Instruction Text</label>
                     <input
                        className="w-full text-sm p-2 border rounded"
                        value={data.longInstruction}
                        onChange={(e) => updateInstruction('longInstruction', e.target.value)}
                     />
                </div>
                {data.longQuestions.map((q, i) => (
                    <div key={q.id} className="flex gap-2 bg-gray-50 p-2 rounded border border-gray-200 items-start group relative">
                         <div className="flex flex-col pt-1 opacity-0 group-hover:opacity-100 transition-opacity absolute -left-6 top-0 h-full justify-center">
                             <button onClick={() => moveQuestion('LONG', i, 'up')} disabled={i === 0} className="p-1 text-gray-400 hover:text-blue-500 disabled:opacity-30"><ArrowUp size={14}/></button>
                             <button onClick={() => moveQuestion('LONG', i, 'down')} disabled={i === data.longQuestions.length - 1} className="p-1 text-gray-400 hover:text-blue-500 disabled:opacity-30"><ArrowDown size={14}/></button>
                         </div>
                        <span className="text-xs font-bold text-gray-400 mt-2">{i+1}.</span>
                        <textarea 
                            className="w-full text-sm p-2 border rounded resize-y min-h-[80px]"
                            placeholder="Question text..."
                            value={q.text}
                            onChange={(e) => updateQuestion('LONG', q.id, 'text', e.target.value)}
                        />
                        <button onClick={() => deleteQuestion('LONG', q.id)} className="text-red-400 hover:text-red-600 mt-2"><Trash2 size={16} /></button>
                    </div>
                ))}
            </div>
        )}
      </div>

    </div>
  );
};

export default Editor;
