
import React from 'react';
import { ExamData } from '../types';

interface ExamPreviewProps {
  data: ExamData;
  forwardRef?: React.Ref<HTMLDivElement>;
}

interface PageBaseProps {
  children: React.ReactNode;
  className?: string;
  fontScale?: number;
  watermark?: string;
  showBorder?: boolean;
}

const PageBase: React.FC<PageBaseProps> = ({ children, className = "", fontScale = 1, watermark, showBorder }) => (
  <div 
    className={`print-container mx-auto my-8 bg-white shadow-xl w-[210mm] min-h-[297mm] p-[10mm] text-black font-serif relative box-border ${className}`}
    style={{ 
        fontFamily: '"Times New Roman", Times, serif',
        fontSize: `${fontScale}rem` // Dynamic font scale
    }}
  >
    {/* Page Border */}
    {showBorder && (
        <div className="absolute inset-4 border-4 border-double border-gray-800 pointer-events-none" />
    )}

    {/* Watermark */}
    {watermark && (
        <div className="absolute inset-0 flex items-center justify-center opacity-[0.08] pointer-events-none overflow-hidden">
            <h1 className="text-8xl font-black text-gray-900 transform -rotate-45 whitespace-nowrap uppercase tracking-widest">{watermark}</h1>
        </div>
    )}

    {/* Content Wrapper to ensure border doesn't overlap text */}
    <div className="relative z-10 h-full">
        {children}
    </div>
  </div>
);

const ExamPreview: React.FC<ExamPreviewProps> = ({ data, forwardRef }) => {
  const { header, mcqs, shortQuestions, longQuestions, settings } = data;

  return (
    <div className="w-full h-full bg-gray-500/20 overflow-y-auto print:p-0 print:bg-white print:overflow-visible">
      <div ref={forwardRef}>
        
        {/* === PAGE 1: Header, Info, Section A === */}
        <PageBase fontScale={settings.fontScale} watermark={settings.watermarkText} showBorder={settings.showBorder}>
          {/* Header */}
          <div className="flex justify-between items-center mb-2">
             {/* Logo - Left */}
             <div className="w-[15%] flex flex-col justify-start items-center">
                  {header.logoUrl ? (
                      <img src={header.logoUrl} alt="Logo Left" className="max-w-full max-h-20 object-contain" />
                  ) : (
                      <div className="w-16 h-16 border-2 border-dashed border-gray-300 rounded-full flex items-center justify-center text-[10px] text-gray-400">
                          LOGO
                      </div>
                  )}
              </div>

              {/* Center Text */}
              <div className="w-[70%] text-center flex flex-col items-center justify-center space-y-0.5">
                  <h1 className="text-[1.5em] font-extrabold uppercase tracking-tight leading-none text-black">{header.schoolName}</h1>
                  <h2 className="text-[1em] font-bold uppercase text-black leading-tight">{header.campus}</h2>
                  <h3 className="text-[1.1em] font-bold underline decoration-2 underline-offset-4 mt-1 text-black">{header.examTitle}</h3>
                  <h3 className="text-[1.25em] font-black uppercase mt-0.5 border-b-2 border-black inline-block px-2">SUBJECT: {header.subject}</h3>
              </div>

              {/* Logo - Right */}
              <div className="w-[15%] flex flex-col justify-start items-center">
                  {header.logoRightUrl ? (
                      <img src={header.logoRightUrl} alt="Logo Right" className="max-w-full max-h-20 object-contain" />
                  ) : (
                       <div className="w-16 h-16 border-2 border-dashed border-gray-300 rounded-full flex items-center justify-center text-[10px] text-gray-400 opacity-30">
                          LOGO
                      </div>
                  )}
              </div>
          </div>

          {/* Info Grid (Meta & Seat No) */}
          <div className="flex justify-between items-end border-b-2 border-black pb-2 mb-2 mt-2 px-1" style={{ fontSize: '0.95em' }}>
            <div className="flex gap-4 lg:gap-8 items-end w-full font-bold">
               <span className="whitespace-nowrap">Date:<span className="border-b border-black border-dashed ml-1 px-2 min-w-[80px] inline-block text-center font-normal">{header.date}</span></span>
               <span className="whitespace-nowrap">Time:<span className="border-b border-black border-dashed ml-1 px-2 min-w-[80px] inline-block text-center font-normal">{header.time}</span></span>
               <span className="whitespace-nowrap">Class:<span className="border-b border-black px-1 ml-1 min-w-[50px] inline-block text-center font-normal">{header.classGrade}</span></span>
            </div>
            
            <div className="flex items-end flex-shrink-0 ml-4">
                <span className="mr-2 font-bold text-[1em]">Seat No.</span>
                <div className="flex border-2 border-black">
                    {[1,2,3,4,5,6,7].map((_, i) => (
                      <div key={i} className="w-6 h-7 border-r-2 last:border-r-0 border-black"></div>
                    ))}
                 </div>
            </div>
          </div>

          {/* Student Box */}
          <div className="border-2 border-black p-1.5 mb-5 mx-1">
              <div className="flex justify-between mb-3 mt-1 px-2" style={{ fontSize: '1em' }}>
                  <div className="flex-1 flex items-end mr-4">
                    <span className="font-bold mr-2">Student Name:</span>
                    <div className="flex-1 border-b-2 border-black"></div>
                  </div>
                  <div className="w-1/3 flex items-end">
                    <span className="font-bold mr-2">Invigilator Sign:</span>
                    <div className="flex-1 border-b-2 border-black"></div>
                  </div>
              </div>
               <div className="flex justify-between font-bold mt-1 pt-1 border-t-2 border-black px-2 text-[0.85em]">
                  <span>Total Marks: <span className="text-[1.1em]">{header.totalMarks}</span></span>
                  <span>Obtained Marks: <span className="inline-block w-16 border-b border-black"></span></span>
                  <span>Pass/Fail: <span className="inline-block w-16 border-b border-black"></span></span>
                  <span>Checked By: <span className="inline-block w-24 border-b border-black"></span></span>
              </div>
          </div>

          {/* Section A */}
          <div className="mb-6 px-1">
              <div className="w-full text-center font-bold mb-4 border-b-2 border-black pb-1">
                  <h4 className="text-[1.15em] uppercase tracking-wide">Section A</h4>
                  <h5 className="text-[1.05em]">Multiple Choice Questions (M.C.Qs) (Marks 20)</h5>
              </div>
              <p className="italic mb-3 font-semibold">{data.mcqInstruction}</p>
              <div className="space-y-3">
                  {mcqs.map((q, idx) => (
                      <div key={q.id} className="leading-snug">
                          {/* Hanging Indent Layout */}
                          <div className="flex items-start gap-2 mb-1.5">
                             <span className="font-semibold whitespace-nowrap">{idx + 1}.</span>
                             <span className="font-semibold">{q.text}</span>
                          </div>
                          
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-2 pl-6">
                              {q.options?.map((opt, optIdx) => (
                                  <span key={optIdx} className="whitespace-nowrap">
                                      <span className="font-bold mr-2">{String.fromCharCode(65 + optIdx)})</span>
                                      {opt}
                                  </span>
                              ))}
                          </div>
                      </div>
                  ))}
              </div>
          </div>
          
          <div className="print:hidden text-center text-gray-400 text-xs mt-10 absolute bottom-4 left-0 right-0">
             (Continued on next page)
          </div>
        </PageBase>

        {/* === PAGE 2: Section B & C === */}
        <PageBase className="break-before-page" fontScale={settings.fontScale} watermark={settings.watermarkText} showBorder={settings.showBorder}>
          {/* Section B */}
          <div className="mb-6 px-1">
               <div className="w-full text-center font-bold mb-4 mt-2 border-b-2 border-black pb-1">
                  <h4 className="text-[1.15em] uppercase tracking-wide">Section B</h4>
                  <h5 className="text-[1.05em]">Short Questions (Marks 50)</h5>
              </div>
              <p className="italic mb-3 font-semibold">{data.shortInstruction}</p>
              <div className="space-y-3 pl-2 leading-relaxed">
                  {shortQuestions.map((q, idx) => (
                      <div key={q.id} className="flex items-start gap-2">
                          <span className="font-bold whitespace-nowrap min-w-[1.2rem]">{idx + 1}.</span>
                          <span>{q.text}</span>
                      </div>
                  ))}
              </div>
          </div>

          {/* Section C */}
          <div className="mb-8 px-1">
               <div className="w-full text-center font-bold mb-4 mt-8 border-b-2 border-black pb-1">
                  <h4 className="text-[1.15em] uppercase tracking-wide">Section C</h4>
                  <h5 className="text-[1.05em]">Long Questions (Marks 30)</h5>
              </div>
              <p className="italic mb-3 font-semibold">{data.longInstruction}</p>
              <div className="space-y-6 pl-2 leading-relaxed">
                  {longQuestions.map((q, idx) => (
                      <div key={q.id} className="flex items-start gap-2">
                          <span className="font-bold whitespace-nowrap min-w-[1.2rem]">{idx + 1}.</span>
                          <span>{q.text}</span>
                      </div>
                  ))}
              </div>
          </div>
          
          {/* Footer info (optional) */}
          <div className="absolute bottom-4 left-0 right-0 text-center text-[10px] text-gray-400 print:hidden">
              Generated with ExamForge
          </div>
        </PageBase>

      </div>
    </div>
  );
};

export default ExamPreview;
