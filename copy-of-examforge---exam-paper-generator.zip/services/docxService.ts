
import { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, AlignmentType, BorderStyle, ImageRun, UnderlineType, VerticalAlign } from "docx";
import FileSaver from "file-saver";
import { ExamData } from "../types";

// Helper to convert Base64 Data URL to Uint8Array for docx ImageRun
const dataUrlToUint8Array = (dataUrl: string) => {
    try {
        if (!dataUrl || !dataUrl.includes(',')) return new Uint8Array();
        const arr = dataUrl.split(',');
        const bstr = atob(arr[1]);
        let n = bstr.length;
        const u8arr = new Uint8Array(n);
        while(n--){
            u8arr[n] = bstr.charCodeAt(n);
        }
        return u8arr;
    } catch (e) {
        console.error("Failed to convert image", e);
        return new Uint8Array();
    }
};

// Helper to get image dimensions to preserve aspect ratio
const getImageDimensions = (base64: string): Promise<{ width: number, height: number }> => {
    return new Promise((resolve) => {
        const img = new Image();
        img.onload = () => resolve({ width: img.width, height: img.height });
        img.onerror = () => resolve({ width: 0, height: 0 }); 
        img.src = base64;
    });
};

export const downloadDocx = async (data: ExamData) => {
  const { header, mcqs, shortQuestions, longQuestions, settings } = data;
  
  // Calculate Scaled Font Sizes (Half-points, so 24 = 12pt)
  const scale = settings.fontScale || 1.0;
  const SIZES = {
      SCHOOL: Math.floor(30 * scale),   // ~15pt (Compact)
      CAMPUS: Math.floor(20 * scale),   // ~10pt
      TITLE: Math.floor(22 * scale),    // ~11pt
      SUBJECT: Math.floor(25 * scale),  // ~12.5pt
      NORMAL: Math.floor(22 * scale),   // ~11pt
      HEADING: Math.floor(24 * scale),  // ~12pt
      SMALL: Math.floor(18 * scale)     // ~9pt
  };

  // Helper to create safe ImageRun
  const createSafeImageRun = async (url: string | undefined): Promise<ImageRun | TextRun> => {
      if (!url) return new TextRun("");
      
      try {
          const dims = await getImageDimensions(url);
          const imageBuffer = dataUrlToUint8Array(url);

          // Validate buffer and dimensions
          if (imageBuffer.length === 0 || dims.width === 0 || dims.height === 0) {
              return new TextRun("");
          }

          // Fit within 60x60 (approx 0.65 inch)
          const maxDim = 60;
          let ratio = Math.min(maxDim / dims.width, maxDim / dims.height);
          
          // Safety check for ratio
          if (!isFinite(ratio) || ratio <= 0) ratio = 1;

          // Ensure dimensions are Integers (Word XML requirement)
          const finalWidth = Math.floor(dims.width * ratio);
          const finalHeight = Math.floor(dims.height * ratio);

          return new ImageRun({
              data: imageBuffer,
              transformation: { 
                  width: finalWidth, 
                  height: finalHeight 
              },
          });
      } catch (e) {
          console.warn("Skipping corrupt image for DOCX", e);
          return new TextRun("");
      }
  };

  // Prepare Logos
  const logoRun = await createSafeImageRun(header.logoUrl);
  const logoRightRun = await createSafeImageRun(header.logoRightUrl);

  // Transparent border for layout tables
  const noBorder = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };

  const doc = new Document({
    sections: [
      {
        properties: {
             page: {
                margin: {
                    top: "0.5in",
                    right: "0.5in",
                    bottom: "0.5in",
                    left: "0.5in",
                },
            },
        },
        children: [
          // 1. MAIN HEADER TABLE (Logo | Text | Logo)
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            borders: {
                top: noBorder, bottom: noBorder, left: noBorder, right: noBorder,
                insideHorizontal: noBorder, insideVertical: noBorder,
            },
            rows: [
              new TableRow({
                children: [
                  // Cell 1: Left Logo
                  new TableCell({
                    width: { size: 15, type: WidthType.PERCENTAGE },
                    verticalAlign: VerticalAlign.CENTER,
                    children: [new Paragraph({ children: [logoRun], alignment: AlignmentType.LEFT })],
                  }),
                  // Cell 2: Center Text
                  new TableCell({
                    width: { size: 70, type: WidthType.PERCENTAGE },
                    verticalAlign: VerticalAlign.CENTER,
                    children: [
                        new Paragraph({
                            alignment: AlignmentType.CENTER,
                            children: [
                                new TextRun({
                                    text: header.schoolName.toUpperCase(),
                                    bold: true,
                                    size: SIZES.SCHOOL, 
                                    font: "Times New Roman"
                                }),
                            ],
                        }),
                        new Paragraph({
                            alignment: AlignmentType.CENTER,
                            spacing: { before: 40 }, // Reduced spacing
                            children: [
                                new TextRun({
                                    text: header.campus || "",
                                    bold: true,
                                    size: SIZES.CAMPUS,
                                    font: "Times New Roman"
                                }),
                            ],
                        }),
                        new Paragraph({
                            alignment: AlignmentType.CENTER,
                            spacing: { before: 60 }, // Reduced spacing
                            children: [
                                new TextRun({
                                    text: header.examTitle,
                                    bold: true,
                                    underline: { type: UnderlineType.SINGLE, color: "000000" },
                                    size: SIZES.TITLE,
                                    font: "Times New Roman"
                                }),
                            ],
                        }),
                        new Paragraph({
                            alignment: AlignmentType.CENTER,
                            spacing: { before: 60 }, // Reduced spacing
                            border: { bottom: { style: BorderStyle.SINGLE, size: 12, space: 1 }}, 
                            children: [
                                new TextRun({ 
                                    text: `SUBJECT: ${header.subject}`, 
                                    bold: true, 
                                    size: SIZES.SUBJECT,
                                    font: "Times New Roman"
                                }) 
                            ]
                        }),
                    ],
                  }),
                  // Cell 3: Right Logo
                  new TableCell({
                    width: { size: 15, type: WidthType.PERCENTAGE },
                    verticalAlign: VerticalAlign.CENTER,
                    children: [new Paragraph({ children: [logoRightRun], alignment: AlignmentType.RIGHT })],
                  }),
                ],
              }),
            ],
          }),

          new Paragraph({ text: "", spacing: { after: 60 } }), // Reduced spacer

          // 2. META INFO & SEAT NO TABLE
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            borders: {
                top: noBorder, bottom: noBorder, left: noBorder, right: noBorder,
                insideHorizontal: noBorder, insideVertical: noBorder,
            },
            rows: [
              new TableRow({
                children: [
                  // Left Col: Date, Time, Class
                  new TableCell({
                    width: { size: 75, type: WidthType.PERCENTAGE },
                    verticalAlign: VerticalAlign.BOTTOM,
                    children: [
                        new Paragraph({
                            children: [
                                new TextRun({ text: "Date: ", bold: true, size: SIZES.NORMAL, font: "Times New Roman" }),
                                new TextRun({ text: `  ${header.date}  `, underline: { type: UnderlineType.DASHED }, size: SIZES.NORMAL, font: "Times New Roman" }),
                                new TextRun({ text: "\tTime: ", bold: true, size: SIZES.NORMAL, font: "Times New Roman" }),
                                new TextRun({ text: `  ${header.time}  `, underline: { type: UnderlineType.DASHED }, size: SIZES.NORMAL, font: "Times New Roman" }),
                                new TextRun({ text: "\tClass: ", bold: true, size: SIZES.NORMAL, font: "Times New Roman" }),
                                new TextRun({ text: `  ${header.classGrade}  `, underline: { type: UnderlineType.SINGLE }, size: SIZES.NORMAL, font: "Times New Roman" }),
                            ],
                            tabStops: [
                                { type: "left", position: 2500 }, // Align Time
                                { type: "left", position: 5000 }, // Align Class
                            ]
                        })
                    ]
                  }),
                  // Right Col: Seat No Label + Grid
                  new TableCell({
                     width: { size: 25, type: WidthType.PERCENTAGE },
                     verticalAlign: VerticalAlign.BOTTOM,
                     children: [
                         new Paragraph({
                             alignment: AlignmentType.RIGHT,
                             children: [new TextRun({ text: "Seat No.  ", bold: true, size: SIZES.HEADING, font: "Times New Roman" })]
                         }),
                         // Seat No Grid Table
                         new Table({
                             alignment: AlignmentType.RIGHT,
                             width: { size: 100, type: WidthType.PERCENTAGE },
                             borders: {
                                 top: { style: BorderStyle.SINGLE, size: 2 },
                                 bottom: { style: BorderStyle.SINGLE, size: 2 },
                                 left: { style: BorderStyle.SINGLE, size: 2 },
                                 right: { style: BorderStyle.SINGLE, size: 2 },
                                 insideVertical: { style: BorderStyle.SINGLE, size: 2 },
                             },
                             rows: [
                                 new TableRow({
                                     height: { value: 300, rule: "exact" }, // Reduced height (300)
                                     children: [
                                         new TableCell({ children: [] }),
                                         new TableCell({ children: [] }),
                                         new TableCell({ children: [] }),
                                         new TableCell({ children: [] }),
                                         new TableCell({ children: [] }),
                                         new TableCell({ children: [] }),
                                         new TableCell({ children: [] }),
                                     ]
                                 })
                             ]
                         })
                     ]
                  })
                ]
              })
            ]
          }),

          new Paragraph({ text: "", spacing: { after: 80 } }), 

          // 3. STUDENT INFO BOX
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            borders: {
                top: { style: BorderStyle.SINGLE, size: 4 },
                bottom: { style: BorderStyle.SINGLE, size: 4 },
                left: { style: BorderStyle.SINGLE, size: 4 },
                right: { style: BorderStyle.SINGLE, size: 4 },
                insideHorizontal: { style: BorderStyle.SINGLE, size: 4 },
                insideVertical: { style: BorderStyle.SINGLE, size: 4 },
            },
            rows: [
                // Row 1: Student Name & Invigilator
                new TableRow({
                    children: [
                        new TableCell({
                            columnSpan: 2,
                            verticalAlign: VerticalAlign.BOTTOM,
                            children: [
                                new Paragraph({
                                    spacing: { before: 60, after: 60 },
                                    children: [
                                        new TextRun({ text: "Student Name: ", bold: true, size: SIZES.NORMAL, font: "Times New Roman" }),
                                        new TextRun({ text: "____________________________________", size: SIZES.NORMAL })
                                    ]
                                })
                            ]
                        }),
                        new TableCell({
                            columnSpan: 2,
                            verticalAlign: VerticalAlign.BOTTOM,
                            children: [
                                new Paragraph({
                                    spacing: { before: 60, after: 60 },
                                    children: [
                                        new TextRun({ text: "Invigilator Sign: ", bold: true, size: SIZES.NORMAL, font: "Times New Roman" }),
                                        new TextRun({ text: "________________________", size: SIZES.NORMAL })
                                    ]
                                })
                            ]
                        }),
                    ]
                }),
                // Row 2: Marks Info
                new TableRow({
                    children: [
                        new TableCell({
                            children: [new Paragraph({ children: [new TextRun({ text: `Total Marks: ${header.totalMarks}`, bold: true, size: SIZES.SMALL, font: "Times New Roman" })] })]
                        }),
                        new TableCell({
                             children: [new Paragraph({ children: [new TextRun({ text: "Obtained Marks: ______", bold: true, size: SIZES.SMALL, font: "Times New Roman" })] })]
                        }),
                        new TableCell({
                             children: [new Paragraph({ children: [new TextRun({ text: "Pass/Fail: ______", bold: true, size: SIZES.SMALL, font: "Times New Roman" })] })]
                        }),
                         new TableCell({
                             children: [new Paragraph({ children: [new TextRun({ text: "Checked By: ____________", bold: true, size: SIZES.SMALL, font: "Times New Roman" })] })]
                        }),
                    ]
                })
            ]
          }),

          new Paragraph({ text: "", spacing: { after: 150 } }), 

          // 4. SECTION A: MCQs
          new Paragraph({
            children: [new TextRun({ text: "SECTION A", bold: true, size: SIZES.HEADING, font: "Times New Roman" })],
            alignment: AlignmentType.CENTER,
            spacing: { before: 100 },
          }),
          new Paragraph({
            children: [new TextRun({ text: "Multiple Choice Questions (M.C.Qs) (Marks 20)", bold: true, size: SIZES.NORMAL, font: "Times New Roman" })],
            alignment: AlignmentType.CENTER,
            border: { bottom: { style: BorderStyle.SINGLE, size: 6, space: 1 } },
            spacing: { after: 80 },
          }),
          new Paragraph({ 
              children: [new TextRun({ text: data.mcqInstruction, italics: true, bold: true, size: SIZES.NORMAL, font: "Times New Roman" })]
          }),
          
          ...mcqs.map((q, i) => [
            new Paragraph({
              children: [new TextRun({ text: `${i + 1}. ${q.text}`, bold: true, size: SIZES.NORMAL, font: "Times New Roman" })],
              spacing: { before: 80 },
              indent: { hanging: 300, left: 300 } // Hanging indent
            }),
            new Paragraph({
              children: [
                new TextRun({ text: `A) ${q.options?.[0] || ''}`, size: SIZES.NORMAL, font: "Times New Roman" }),
                new TextRun({ text: `\tB) ${q.options?.[1] || ''}`, size: SIZES.NORMAL, font: "Times New Roman" }),
                new TextRun({ text: `\tC) ${q.options?.[2] || ''}`, size: SIZES.NORMAL, font: "Times New Roman" }),
                new TextRun({ text: `\tD) ${q.options?.[3] || ''}`, size: SIZES.NORMAL, font: "Times New Roman" }),
              ],
              tabStops: [
                  { type: "left", position: 2500 },
                  { type: "left", position: 5000 },
                  { type: "left", position: 7500 },
              ],
              indent: { left: 600 }
            }),
          ]).flat(),

          // 5. SECTION B: Short Questions
          new Paragraph({
            children: [new TextRun({ text: "SECTION B", bold: true, size: SIZES.HEADING, font: "Times New Roman" })],
            alignment: AlignmentType.CENTER,
            pageBreakBefore: true,
            spacing: { before: 200 },
          }),
          new Paragraph({
            children: [new TextRun({ text: "Short Questions (Marks 50)", bold: true, size: SIZES.NORMAL, font: "Times New Roman" })],
            alignment: AlignmentType.CENTER,
            border: { bottom: { style: BorderStyle.SINGLE, size: 6, space: 1 } },
            spacing: { after: 80 },
          }),
          new Paragraph({ 
              children: [new TextRun({ text: data.shortInstruction, italics: true, bold: true, size: SIZES.NORMAL, font: "Times New Roman" })]
           }),
          ...shortQuestions.map((q, i) => 
            new Paragraph({
              children: [new TextRun({ text: `${i + 1}. ${q.text}`, size: SIZES.NORMAL, font: "Times New Roman" })],
              spacing: { before: 80 },
              indent: { hanging: 300, left: 300 }
            })
          ),

          // 6. SECTION C: Long Questions
          new Paragraph({
            children: [new TextRun({ text: "SECTION C", bold: true, size: SIZES.HEADING, font: "Times New Roman" })],
            alignment: AlignmentType.CENTER,
            spacing: { before: 200 },
          }),
          new Paragraph({
            children: [new TextRun({ text: "Long Questions (Marks 30)", bold: true, size: SIZES.NORMAL, font: "Times New Roman" })],
            alignment: AlignmentType.CENTER,
            border: { bottom: { style: BorderStyle.SINGLE, size: 6, space: 1 } },
            spacing: { after: 80 },
          }),
          new Paragraph({ 
              children: [new TextRun({ text: data.longInstruction, italics: true, bold: true, size: SIZES.NORMAL, font: "Times New Roman" })]
          }),
          ...longQuestions.map((q, i) => 
            new Paragraph({
               children: [new TextRun({ text: `${i + 1}. ${q.text}`, size: SIZES.NORMAL, font: "Times New Roman" })],
              spacing: { before: 80 },
              indent: { hanging: 300, left: 300 }
            })
          ),
        ],
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  FileSaver.saveAs(blob, `${header.subject}_Exam.docx`);
};
