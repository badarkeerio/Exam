import { GoogleGenAI, Type, Schema } from "@google/genai";
import { ExamData, Question } from "../types";

// Helper to create a unique ID
const generateId = () => Math.random().toString(36).substr(2, 9);

const examSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    mcqs: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          text: { type: Type.STRING, description: "The question text" },
          options: { 
            type: Type.ARRAY, 
            items: { type: Type.STRING },
            description: "Array of 4 options"
          },
        },
        required: ["text", "options"]
      },
      description: "List of multiple choice questions",
    },
    shortQuestions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          text: { type: Type.STRING, description: "The question text" },
        },
        required: ["text"]
      },
      description: "List of short answer questions",
    },
    longQuestions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          text: { type: Type.STRING, description: "The question text" },
        },
        required: ["text"]
      },
      description: "List of long answer detailed questions",
    },
  },
  required: ["mcqs", "shortQuestions", "longQuestions"],
};

export const generateExamContent = async (
  subject: string,
  grade: string,
  topic: string
): Promise<Partial<ExamData> | null> => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API Key is missing from environment");
    return null;
  }

  const ai = new GoogleGenAI({ apiKey });

  try {
    const prompt = `Generate a chemistry exam paper content for ${subject}, Grade ${grade}. 
    Topic focus: ${topic || "General"}.
    Include 5 MCQs, 5 Short Questions, and 2 Long Questions.
    Ensure scientific formulas are written clearly in text format.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: examSchema,
        systemInstruction: "You are a helpful assistant that generates structured exam content for schools."
      },
    });

    const text = response.text;
    if (!text) return null;

    const data = JSON.parse(text);

    // Map to our internal structure with IDs
    return {
      mcqs: data.mcqs.map((q: any) => ({ ...q, id: generateId(), type: 'MCQ', marks: 1 })),
      shortQuestions: data.shortQuestions.map((q: any) => ({ ...q, id: generateId(), type: 'SHORT', marks: 5 })),
      longQuestions: data.longQuestions.map((q: any) => ({ ...q, id: generateId(), type: 'LONG', marks: 10 })),
    };
  } catch (error) {
    console.error("Gemini Generation Error:", error);
    throw error;
  }
};